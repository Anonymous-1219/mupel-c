package com.mupel.floatingtimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

class FloatingOverlayService : Service() {

  companion object {
    const val EXTRA_SECONDS = "extra_seconds"
    const val EXTRA_RUNNING = "extra_running"
    private const val CHANNEL_ID = "mupel_floating_timer"
    private const val NOTIFICATION_ID = 4201

    /** Set by FloatingTimerModule so bubble button taps can reach JS. */
    var actionListener: ((String) -> Unit)? = null

    private var instance: FloatingOverlayService? = null

    fun updateState(secondsRemaining: Int, running: Boolean, paused: Boolean) {
      instance?.applyState(secondsRemaining, running, paused)
    }
  }

  private lateinit var windowManager: WindowManager
  private var bubbleView: View? = null
  private var expanded = false
  private var secondsRemaining = 0
  private var running = true
  private var timeLabel: TextView? = null

  private val handler = Handler(Looper.getMainLooper())
  private val tickRunnable = object : Runnable {
    override fun run() {
      if (running && secondsRemaining > 0) {
        secondsRemaining -= 1
        renderTime()
      }
      handler.postDelayed(this, 1000)
    }
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    instance = this
    windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    secondsRemaining = intent?.getIntExtra(EXTRA_SECONDS, secondsRemaining) ?: secondsRemaining
    running = intent?.getBooleanExtra(EXTRA_RUNNING, true) ?: true

    startForeground(NOTIFICATION_ID, buildNotification())
    if (bubbleView == null) {
      addBubbleView()
      handler.post(tickRunnable)
    }
    return START_STICKY
  }

  override fun onDestroy() {
    handler.removeCallbacks(tickRunnable)
    bubbleView?.let {
      try {
        windowManager.removeView(it)
      } catch (e: Exception) {
        // view already detached — safe to ignore
      }
    }
    bubbleView = null
    instance = null
    super.onDestroy()
  }

  private fun applyState(seconds: Int, isRunning: Boolean, isPaused: Boolean) {
    secondsRemaining = seconds
    running = isRunning
    renderTime()
    if (!isRunning && !isPaused && seconds <= 0) {
      stopSelf()
    }
    updateNotification()
  }

  private fun renderTime() {
    val m = secondsRemaining / 60
    val s = secondsRemaining % 60
    timeLabel?.text = String.format("%d:%02d", m, s)
    updateNotification()
  }

  // ---------------- overlay view ----------------

  private fun addBubbleView() {
    val density = resources.displayMetrics.density
    val container = LinearLayout(this)
    container.orientation = LinearLayout.VERTICAL
    container.gravity = Gravity.CENTER

    val bg = GradientDrawable()
    bg.cornerRadius = 20 * density
    bg.setColor(Color.parseColor("#1A1A1D"))
    bg.setStroke((1 * density).toInt(), Color.parseColor("#8B5CF6"))
    container.background = bg
    container.setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (10 * density).toInt())

    val label = TextView(this)
    label.setTextColor(Color.WHITE)
    label.textSize = 16f
    label.text = String.format("%d:%02d", secondsRemaining / 60, secondsRemaining % 60)
    timeLabel = label
    container.addView(label)

    val actionsRow = LinearLayout(this)
    actionsRow.orientation = LinearLayout.HORIZONTAL
    actionsRow.gravity = Gravity.CENTER
    actionsRow.visibility = View.GONE

    actionsRow.addView(makeActionButton("⏸") { actionListener?.invoke("pause") })
    actionsRow.addView(makeActionButton("+5") { actionListener?.invoke("plus5") })
    actionsRow.addView(makeActionButton("✕") { actionListener?.invoke("stop") })
    container.addView(actionsRow)

    val size = (64 * density).toInt()
    val params = WindowManager.LayoutParams(
      WindowManager.LayoutParams.WRAP_CONTENT,
      WindowManager.LayoutParams.WRAP_CONTENT,
      overlayWindowType(),
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
      PixelFormat.TRANSLUCENT
    )
    params.gravity = Gravity.TOP or Gravity.START
    val metrics = DisplayMetrics()
    windowManager.defaultDisplay.getMetrics(metrics)
    params.x = metrics.widthPixels - size - (16 * density).toInt()
    params.y = metrics.heightPixels / 3

    attachDragHandling(container, params, metrics)
    container.setOnClickListener {
      expanded = !expanded
      actionsRow.visibility = if (expanded) View.VISIBLE else View.GONE
    }

    windowManager.addView(container, params)
    bubbleView = container
  }

  private fun makeActionButton(label: String, onTap: () -> Unit): TextView {
    val density = resources.displayMetrics.density
    val tv = TextView(this)
    tv.text = label
    tv.setTextColor(Color.parseColor("#8B5CF6"))
    tv.textSize = 14f
    tv.setPadding((10 * density).toInt(), (6 * density).toInt(), (10 * density).toInt(), (6 * density).toInt())
    tv.setOnClickListener { onTap() }
    return tv
  }

  private fun overlayWindowType(): Int {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
      @Suppress("DEPRECATION")
      WindowManager.LayoutParams.TYPE_PHONE
    }
  }

  private fun attachDragHandling(
    view: View,
    params: WindowManager.LayoutParams,
    metrics: DisplayMetrics
  ) {
    var initialX = 0
    var initialY = 0
    var touchStartX = 0f
    var touchStartY = 0f
    var dragging = false

    view.setOnTouchListener { v, event ->
      when (event.action) {
        MotionEvent.ACTION_DOWN -> {
          initialX = params.x
          initialY = params.y
          touchStartX = event.rawX
          touchStartY = event.rawY
          dragging = false
          true
        }
        MotionEvent.ACTION_MOVE -> {
          val dx = (event.rawX - touchStartX).toInt()
          val dy = (event.rawY - touchStartY).toInt()
          if (Math.abs(dx) > 6 || Math.abs(dy) > 6) dragging = true
          params.x = initialX + dx
          params.y = initialY + dy
          windowManager.updateViewLayout(view, params)
          true
        }
        MotionEvent.ACTION_UP -> {
          if (dragging) {
            // Snap to the nearest horizontal edge.
            val viewWidth = view.width.takeIf { it > 0 } ?: (64 * resources.displayMetrics.density).toInt()
            val screenCenter = metrics.widthPixels / 2
            val bubbleCenter = params.x + viewWidth / 2
            params.x = if (bubbleCenter < screenCenter) 0 else metrics.widthPixels - viewWidth
            windowManager.updateViewLayout(view, params)
          } else {
            v.performClick()
          }
          true
        }
        else -> false
      }
    }
  }

  // ---------------- notification ----------------

  private fun buildNotification(): android.app.Notification {
    createChannelIfNeeded()
    val m = secondsRemaining / 60
    val s = secondsRemaining % 60
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setContentTitle("Mupel Clock")
      .setContentText(String.format("Floating timer · %d:%02d remaining", m, s))
      .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .build()
  }

  private fun updateNotification() {
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.notify(NOTIFICATION_ID, buildNotification())
  }

  private fun createChannelIfNeeded() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (nm.getNotificationChannel(CHANNEL_ID) == null) {
        val channel = NotificationChannel(
          CHANNEL_ID,
          "Floating timer",
          NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)
      }
    }
  }
}
