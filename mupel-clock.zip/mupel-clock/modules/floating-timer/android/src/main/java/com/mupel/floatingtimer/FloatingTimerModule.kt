package com.mupel.floatingtimer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class FloatingTimerModule : Module() {

  override fun definition() = ModuleDefinition {
    Name("FloatingTimer")

    Events("onBubbleAction")

    OnCreate {
      // Route taps from the overlay's Pause / +5 / Stop buttons back into JS.
      FloatingOverlayService.actionListener = { action ->
        sendEvent("onBubbleAction", mapOf("action" to action))
      }
      return@OnCreate
    }

    Function("hasOverlayPermission") {
      val context = appContext.reactContext
      if (context == null) {
        return@Function false
      }
      val granted =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          Settings.canDrawOverlays(context)
        } else {
          true
        }
      return@Function granted
    }

    Function("requestOverlayPermission") {
      val context = appContext.reactContext
      if (context == null) {
        return@Function null
      }
      val intent = Intent(
        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
        Uri.parse("package:${context.packageName}")
      )
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      context.startActivity(intent)
      return@Function null
    }

    Function("showBubble") { secondsRemaining: Int ->
      val context = appContext.reactContext
      if (context == null) {
        return@Function null
      }
      val intent = Intent(context, FloatingOverlayService::class.java)
      intent.putExtra(FloatingOverlayService.EXTRA_SECONDS, secondsRemaining)
      intent.putExtra(FloatingOverlayService.EXTRA_RUNNING, true)
      startServiceCompat(context, intent)
      return@Function null
    }

    Function("updateBubble") { secondsRemaining: Int, running: Boolean, paused: Boolean ->
      FloatingOverlayService.updateState(secondsRemaining, running, paused)
      return@Function null
    }

    Function("hideBubble") {
      val context = appContext.reactContext
      if (context == null) {
        return@Function null
      }
      context.stopService(Intent(context, FloatingOverlayService::class.java))
      return@Function null
    }
  }

  private fun startServiceCompat(context: Context, intent: Intent) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      context.startForegroundService(intent)
    } else {
      context.startService(intent)
    }
  }
}
